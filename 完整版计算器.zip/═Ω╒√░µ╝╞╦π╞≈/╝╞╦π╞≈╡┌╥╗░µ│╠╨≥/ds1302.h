#include<reg52.h>
sbit ce=P2^0;
sbit dio=P2^1;
sbit sclk=P2^2;

void write(unsigned char add,unsigned char date);//1302;
unsigned char read(unsigned char add);//1302
void ds1302_init();//1302