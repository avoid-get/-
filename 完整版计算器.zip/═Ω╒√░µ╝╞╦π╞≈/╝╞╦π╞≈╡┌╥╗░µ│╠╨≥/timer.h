void dis_char_alarm(void);
void init_var_time();
void display_t(void);
void get_time(void);
void init_timer_char(void);
void dis_set_time(unsigned char num,unsigned char mdata);
void dis_set_alarm(char num,unsigned char  mdata);
void dis_timer_char() ;
void adj_timer_char();
void alarm_sub();
void timer_sub();
void alarm_add();
void timer_add();
void label_shanshuo();
void dis_real_time();
void set_sfm(unsigned char shi,unsigned char fen,unsigned char miao);

