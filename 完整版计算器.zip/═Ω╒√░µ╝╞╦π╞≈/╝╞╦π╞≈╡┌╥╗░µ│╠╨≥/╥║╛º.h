void delay1(int );
void lcd_wcmd(unsigned char );
void lcd_pos(unsigned char );
void lcd_wdat(unsigned char );
void lcd_init();
