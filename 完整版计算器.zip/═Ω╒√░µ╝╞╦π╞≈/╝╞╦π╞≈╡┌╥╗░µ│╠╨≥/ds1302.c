#include "ds1302.h"	 
#define uchar unsigned char
#define uint unsigned int
void delayms1(unsigned int z)//��ʱ�ӳ���
{
	unsigned int  x,y;
	for(y=z;y>0;y--)
		for(x=110;x>0;x--);
}
void write(uchar add,uchar date)//1302
{
	uchar temp,t;
	ce=0;
	sclk=0;
	ce=1;
	temp=add;
	for(t=0;t<8;t++)
	{
		if((temp&0x01)==1)
		{
			dio=1;
		}
		else
			dio=0;
		sclk=1;
		delayms1(5);
		sclk=0;
		temp=temp>>1;
	}
	temp=date;
	for(t=8;t>0;t--)
	{
		if((temp&0x01)==1)
		{
			dio=1;
		}
		else
			dio=0;
		sclk=1;
		delayms1(5);
		sclk=0;
		temp=temp>>1;
	}
	ce=0;
}
uchar read(uchar add)//1302
{
	uchar temp,t;
	ce=0;
	sclk=0;
	ce=1;
	temp=add;
	for(t=0;t<8;t++)
	{
		if((temp&0x01)==1)
			dio=1;
		else
			dio=0;
		sclk=1;
		sclk=0;
		temp>>=1;
	}
	temp=0;
	for(t=0;t<7;t++)
	{
		if(dio==1)
			temp=temp|0x80;
		else
			temp=temp&0x7f;
		sclk=1;
		sclk=0;
		temp>>=1;
	}
	return temp;
}
void ds1302_init()//1302
{
	write(0x8e,0x00);//д����
	write(0x80,0x52); //д��
	write(0x82,0x59);//д��
	write(0x84,0x11); //дʱ
	write(0x86,0x09);
	write(0x88,0x05);
	write(0x8c,0x14);
	write(0x8a,0x02);
	write(0x8e,0x00);
   // write(0x84,0x02); //дʱ		
}