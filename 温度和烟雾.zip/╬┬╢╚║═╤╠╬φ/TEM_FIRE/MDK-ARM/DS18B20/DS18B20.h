#ifndef _DS18B20_H_
#define _DS18B20_H_

#include "main.h"

#define  DS18B20_DQ_OUT_HIGH       HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET)
#define  DS18B20_DQ_OUT_LOW        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET)
#define  DS18B20_DQ_IN             HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_5)


short DS18B20_Get_Temperature(uint8_t a);
uint8_t DS18B20_Init(void);
void DS18B20_Start(void);
uint8_t DS18B20_Read_Byte(void);
uint8_t DS18B20_Read_Bit(void);
void DS18B20_Write_Byte(uint8_t data);
uint8_t DS18B20_Check(void);
void DS18B20_Rst(void);
void DS18B20_IO_IN(void);
void delay_us(uint32_t time);

#endif
